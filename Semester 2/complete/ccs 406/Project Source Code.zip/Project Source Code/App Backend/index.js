const http = require('http');
const PORT = 3001;
const mysql = require('mysql');
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'farm',
});
connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to database');
});

var server = http.createServer((req, res) => {
  if (req.url === '/changeTankPumpStatus') {
    let body = '';
     req.on('data', (chunk) => {
      body += chunk.toString();  
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.tankPumpStatus)
        const sql = ` UPDATE tankrecords SET tankPumpStatus='${response.tankPumpStatus}' WHERE  id=1  `;
        connection.query(sql, (err, result) => { 
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(response));
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  }else if (req.url === '/changeSprinklerPumpStatus') {
    let body = '';
    req.on('data', (chunk) => {
    body += chunk.toString(); 
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.sprinklerPumpStatus)
        const sql = ` UPDATE greenhouserecords SET sprinklerPumpStatus='${response.sprinklerPumpStatus}' WHERE  id=1  `;
        connection.query(sql, (err, result) => { 
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(response));
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  }
  else if (req.url === '/changeRobotStatus') {
    let body = '';
    req.on('data', (chunk) => {
    body += chunk.toString(); 
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        console.log(response.robotStatus)
        const sql = ` UPDATE activitieslogs SET robot='${response.robotStatus}' WHERE  id=1  `;
        connection.query(sql, (err, result) => { 
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(response));
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  }
  else if (req.url === '/changeStoreFanStatus') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.storeFanStatus)
        const sql = ` UPDATE storerecords SET storeFanAction='${response.storeFanStatus}' WHERE  id=1  `;
        connection.query(sql, (err, result) => {         
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(response));
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  } else if (req.url === '/changeSprayStemStatus') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();     
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.CowSprayStatus)
        const sql = ` UPDATE automatedspraysystem SET CowSprayStatus='${response.CowSprayStatus}' WHERE  id=1  `;
        connection.query(sql, (err, result) => {         
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(response));
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  }else if (req.url === '/resetCows') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();     
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        const sql = ` UPDATE activitieslogs SET numberOfCows='0' WHERE  id=1  `;
        connection.query(sql, (err, result) => {         
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(result));
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  }
   else if (req.url === '/fetchTankPumpStatus') {
    let body = '';
    req.on('data', (chunk) => {
    body += chunk.toString();
    });
    req.on('end', () => {
      try {
        
        
        const response = JSON.parse(body);
        // console.log(response.id)
        const sql = ` SELECT tankPumpStatus FROM tankrecords WHERE  id='${response.id}'  `;
        connection.query(sql, (err, result) => {
        result.forEach((row) => {
            let tankPumpStatus = row.tankPumpStatus;
            if(tankPumpStatus =="M"){
              tankPumpStatus ="ON";
            }else{
              tankPumpStatus="OFF";
           }
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(tankPumpStatus));
          });
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  }else if (req.url === '/fetchRobotStatus') {
    let body = '';
    req.on('data', (chunk) => {
    body += chunk.toString();
    });
    req.on('end', () => {
      try {
        
        
        const response = JSON.parse(body);
        // console.log(response.id)
        const sql = `SELECT robot FROM activitieslogs WHERE  id=1  `;
        connection.query(sql, (err, result) => {
        result.forEach((row) => {
            let robotStatus = row.robot;
            if(robotStatus =="R"){
              robotStatus ="ON";
            }else{
              robotStatus="OFF";
           }
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(robotStatus));
          });
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  }
  else if (req.url === '/fetchWaterLevel') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();   
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.id)
        const sql = ` SELECT waterLevel FROM tankrecords WHERE  id='${response.id}'  `;
        connection.query(sql, (err, result) => {
        result.forEach((row) => {
            let waterLevel = row.waterLevel;          
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(waterLevel));
          });
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  } else if (req.url === '/fetchSprinklerPumpStatus') {
    let body = '';
    req.on('data', (chunk) => {
    body += chunk.toString();     
    });
   req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.id)
        const sql = ` SELECT sprinklerPumpStatus FROM greenhouserecords WHERE  id='${response.id}'  `;
        connection.query(sql, (err, result) => {
        result.forEach((row) => {
            let sprinklerPumpStatus = row.sprinklerPumpStatus;
            if(sprinklerPumpStatus =="G"){
              sprinklerPumpStatus ="ON";
            }else{
              sprinklerPumpStatus="OFF";
           }
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(sprinklerPumpStatus));
          });
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  }else if (req.url === '/fetchMoistureContent') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();   
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.id)
        const sql = ` SELECT soilMoistureReading FROM greenhouserecords WHERE  id='${response.id}'  `;
        connection.query(sql, (err, result) => {
        result.forEach((row) => { 
            let soilMoistureReading = row.soilMoistureReading;
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(soilMoistureReading));
          });
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  }  else if (req.url === '/fetchStoreFanStatus') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();  
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.id)
        const sql = ` SELECT storeFanAction FROM storerecords WHERE  id='${response.id}'  `;
        connection.query(sql, (err, result) => {
        result.forEach((row) => {
            let storeFanAction = row.storeFanAction;
            if(storeFanAction =="S"){
              storeFanAction ="ON";
            }else{
              storeFanAction="OFF";
           }
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(storeFanAction));
          });
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  } else if (req.url === '/fetchTemperature') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();  
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.id)
        const sql = ` SELECT * FROM storerecords WHERE  id='${response.id}'  `;
        connection.query(sql, (err, result) => {
        result.forEach((row) => {
            let temperatureReading = row.temperatureReading;
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(temperatureReading));
          });
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  } 
   else if (req.url === '/fetchHumidity') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();  
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.id)
        const sql = ` SELECT * FROM storerecords WHERE  id='${response.id}'  `;
        connection.query(sql, (err, result) => {
        result.forEach((row) => {
            let humidity = row.humidity;
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(humidity));
          });
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  }else if (req.url === '/fetchAutomatedSpraySystem') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();  
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.id)
        const sql = ` SELECT CowSprayStatus FROM automatedspraysystem WHERE  id='${response.id}'  `;
        connection.query(sql, (err, result) => {
        result.forEach((row) => {
            let CowSprayStatus = row.CowSprayStatus;
            if(CowSprayStatus =="C"){
              CowSprayStatus ="ON";
            }else{
              CowSprayStatus="OFF";
           }
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(CowSprayStatus));
          });
    
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  } else if (req.url === '/fetchFarmActivitiesLogs') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();  
    });
    req.on('end', () => {
      try {
        const response = JSON.parse(body);
        // console.log(response.id)
        const sql = ` SELECT tankpump, sprinklers,ac,spray,numberOfCows FROM activitieslogs WHERE  id='${response.id}'  `;
        connection.query(sql, (err, result) => {
        result.forEach((row) => {  
           console.log(row);
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(row));
          });
      });
      } catch (error) {
        console.error(error);
        res.writeHead(400, { 'Content-Type': 'text/plain' });
        res.end('Invalid request data');
      }
    });
  } else if (req.url === '/reports') {
    let body = '';
    req.on('data', (chunk) => {
        body += chunk.toString();  
    });
    req.on('end', () => {
        try {
            const response = JSON.parse(body);
            console.log("here" + response);
            const sql = 'SELECT * FROM activity_reports ORDER BY timestamp DESC';
            connection.query(sql, (err, result) => {
                if (err) {
                    console.error(err);
                    res.writeHead(500, { 'Content-Type': 'text/plain' });
                    res.end('Internal Server Error');
                } else {
                    console.log("Reports:", JSON.stringify(result));

                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify(result));
                }
            });
        } catch (error) {
            console.error(error);
            res.writeHead(400, { 'Content-Type': 'text/plain' });
            res.end('Invalid request data');
        }
    });
}

   else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not found');
  }
});

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
