const express = require('express');
const app = express();
const PORT = 3000; 
app.use(express.json());
const mysql = require('mysql');
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'farm',
});
connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to database');
});
app.post('/data', (req, res) => {
  try {
    const data = req.body;
    const receivedData = data.dataSend;
    console.log(receivedData)
    console.log("      ");
    console.log("Received Farm Reading... ");
    let temperature, humidity, moisture, distance, Sprinkling, Spraying, Tankpumping, asSpinning ,robotValue;
    if(receivedData != null){
    let lines = receivedData.split('$');
    lines.forEach(line => {
      if (line.includes("Temperature:")) {
        temperature = line.split("Temperature:")[1].trim();
      } else if (line.includes("Humidity:")) {
        humidity = line.split("Humidity:")[1].trim();
      } else if (line.includes("Moisture:")) {
        moisture = line.split("Moisture:")[1].trim();
      } else if (line.includes("Distance:")) {
        distance = line.split("Distance:")[1].trim();
      } else if (line.includes("Sprinkling:")) {
        Sprinkling = line.split("Sprinkling:")[1].trim();
      } else if (line.includes("Spraying:")) {
        Spraying = line.split("Spraying:")[1].trim();
      } else if (line.includes("Tankpumping:")) {
        Tankpumping = line.split("Tankpumping:")[1].trim();
      } else if (line.includes("asSpinning:")) {
        asSpinning = line.split("asSpinning:")[1].trim();
      }
      else if (line.includes("robotStatus:")) {
        robotValue = line.split("robotStatus:")[1].trim();
      }
    });
  }
     console.log("Temperature:", temperature,"°");
     console.log("Humidity:", humidity,"%");
     console.log("Moisture:", moisture,"%");
     function calculateVolume(height) {
      const pi = Math.PI;
      const volume = pi * Math.pow(3.4, 2) * (11-height);
      return volume;
    }
    const tankVolume = calculateVolume(distance).toFixed(2);
    // console.log("Tank Capacity:", tankVolume,"cm³");
    // console.log("Drip pump:",Sprinkling);
    // console.log("Cow Spraying:",Spraying);
    // console.log("Tankpumping:",Tankpumping);
    console.log("asSpinning:",asSpinning);
    console.log("robot Status:", robotValue);
    
    
    const spraySql = `SELECT spray FROM activitieslogs WHERE id='1'`;
    connection.query(spraySql, (err, result) => {
        if (err) reject(err);
        const sprayStatus = result && result.length > 0 ? result[0].spray : null;
                          let storedValue = [1];
                          storedValue[0] = sprayStatus;
                          // console.log(storedValue[0])
                          
                          if(storedValue[0] != asSpinning){
                          const sprinklingQuery = 'UPDATE activitieslogs SET numberOfCows = numberOfCows+1';
                          connection.query(sprinklingQuery, [Sprinkling], (err, results) => {
                          if (err) {
                            console.error('Error updating temperature:', err);
                            return;
                          } 
                          });
                          }
      });
  


if(robotValue == 'r'){
    const sprinklingQuery = 'UPDATE activitieslogs SET sprinklers = ?,spray =?,tankpump =?, ac=?,robot=?';
    connection.query(sprinklingQuery, [Sprinkling,Spraying,Tankpumping,asSpinning,robotValue], (err, results) => {
      if (err) {
        console.error('Error updating temperature:', err);
        return;
      } 
    });

  }else{

    const sprinklingQuery = 'UPDATE activitieslogs SET sprinklers = ?,spray =?,tankpump =?, ac=?';
    connection.query(sprinklingQuery, [Sprinkling,Spraying,Tankpumping,asSpinning], (err, results) => {
      if (err) {
        console.error('Error updating temperature:', err);
        return;
      } 
    });

  }

const sprinklingQuery = 'UPDATE activitieslogs SET sprinklers = ?,spray =?,tankpump =?, ac=?';
connection.query(sprinklingQuery, [Sprinkling,Spraying,Tankpumping,asSpinning], (err, results) => {
  if (err) {
    console.error('Error updating temperature:', err);
    return;
  } 
});


    const storeQuery = 'UPDATE storerecords SET temperatureReading = ?';
    connection.query(storeQuery, [temperature], (err, results) => {
      if (err) {
        console.error('Error updating temperature:', err);
        return;
      } 
    });
    const storeHumidityQuery = 'UPDATE storerecords SET humidity= ?';
    connection.query(storeHumidityQuery, [humidity], (err, results) => {
      if (err) {
        console.error('Error updating Humidity:', err);
        return;
      } 
    });



    const greenhouseQuery = 'UPDATE greenhouserecords SET soilMoistureReading = ?';
    connection.query(greenhouseQuery, [moisture], (err, results) => {
      if (err) {
        console.error('Error updating Moisture:', err);
        return;
      } 
    });
   
    const tankQuery = 'UPDATE tankrecords SET waterLevel = ?';
    connection.query(tankQuery, [tankVolume], (err, results) => {
      if (err) {
        console.error('Error updating temperature:', err);
        return;
      } 
    });
   async function fetchData() {
      try {
        const tankPumpSql = `SELECT tankPumpStatus FROM tankrecords WHERE id='1'`;
        const storefanSql = `SELECT storeFanAction FROM storerecords WHERE id='1'`;
        const greenHouseSql = `SELECT sprinklerPumpStatus FROM greenhouserecords WHERE id='1'`;
        const sprayHouseSql = `SELECT CowSprayStatus FROM automatedspraysystem WHERE id='1'`;
        const robotSql = `SELECT robot FROM activitieslogs WHERE id='1'`;

        const tankPumpStatusPromise = new Promise((resolve, reject) => {
          connection.query(tankPumpSql, (err, result) => {
            if (err) reject(err);
            const tankPumpStatus = result && result.length > 0 ? result[0].tankPumpStatus : null;
            resolve(tankPumpStatus);
          });
        });
       const storeFanActionPromise = new Promise((resolve, reject) => {
          connection.query(storefanSql, (err, result) => {
            if (err) reject(err);
            const storeFanAction = result && result.length > 0 ? result[0].storeFanAction : null;
            resolve(storeFanAction);
          });
        });
      const sprinklerPumpStatusPromise = new Promise((resolve, reject) => {
          connection.query(greenHouseSql, (err, result) => {
            if (err) reject(err);
            const sprinklerPumpStatus = result && result.length > 0 ? result[0].sprinklerPumpStatus : null;
            resolve(sprinklerPumpStatus);
          });
        });
        const robotPromise = new Promise((resolve, reject) => {
          connection.query(robotSql, (err, result) => {
            if (err) reject(err);
            const robotStatus = result && result.length > 0 ? result[0].robot : null;
            resolve(robotStatus);
          });
        });
        const sprayHouseStatusPromise = new Promise((resolve, reject) => {
          connection.query(sprayHouseSql, (err, result) => {
            if (err) reject(err);
            const sprayHouseStatus = result && result.length > 0 ? result[0].CowSprayStatus : null;
            resolve(sprayHouseStatus);
          });
        });
        const [tankPumpStatus, storeFanAction, sprinklerPumpStatus, sprayHouseStatus,robotStatus] = await Promise.all([
          tankPumpStatusPromise,
          storeFanActionPromise,
          sprinklerPumpStatusPromise,
          sprayHouseStatusPromise,
          robotPromise
        ]);
        // console.log('Store Fan Action:', storeFanAction);
        // console.log('Sprinkler Pump Status:', sprinklerPumpStatus);
        // console.log('Tank Pump Status:', tankPumpStatus);
        // console.log('Spray House Status:', sprayHouseStatus);
        // console.log('Robot:',robotStatus);
        let returnData = storeFanAction + "" + sprinklerPumpStatus + "" + sprayHouseStatus+"" + tankPumpStatus+""+robotStatus ;
        res.json({ status: returnData });
      } catch (error) {
        console.error('Error:', error);
      } finally {
      }
    }
    fetchData();
  } catch (error) {
    console.error('Error parsing JSON:', error);
    res.status(400).json({ status: 'error', message: 'Invalid JSON' });
  }
});
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
